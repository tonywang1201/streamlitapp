import streamlit as st

if 'option1' not in st.session_state:
    st.session_state.option1 = []

if 'option2' not in st.session_state:
    st.session_state.option2 = []


def button_action():
    st.session_state.option1 = [1, 2, 3, 4]

def box1_action():
    selection1 = st.session_state.option1
    print(selection1)
    st.info(selection1, icon="ℹ️")

selection1 = st.selectbox(
    "How would you like to be contacted?",
    st.session_state.option1,
    on_change=box1_action
)

selection2 = st.selectbox(
    "Second selectbox",
    st.session_state.option2,

)

st.button("Reset", type="primary", on_click=button_action)

st.write("You selected:", selection1)

st.write("You selected:", selection2)