import streamlit as st
import pandas as pd
import random
import time
import os
import re
import pyperclip

# ==========================================
# 1. 全局变量与配置
# ==========================================
st.set_page_config(
    page_title="Database Search Tool by wang -- v2",
    page_icon=":floppy_disk",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ==========================================
# 2. 设置 session_state 初始值
# ==========================================

if 'database_path' not in st.session_state:
    st.session_state.database_path = 'S:/CTG/11_HNTE/database_test.xlsx'

if 'project_name' not in st.session_state:
    st.session_state.project_name = "Enter project name"

if "keypoint" not in st.session_state:
    st.session_state.keypoint = []

if "vendor_name" not in st.session_state:
    st.session_state.vendor_name = []

# if "vendor_name_selection" not in st.session_state:
    # st.session_state.vendor_name_selection = []

if "product_list" not in st.session_state:
    st.session_state.product_list = []

# if "product_list_selection" not in st.session_state:
    # st.session_state.product_list_selection = []

if "txt" not in st.session_state:
    st.session_state.txt = ""

# if "imgurl" not in st.session_state:
st.session_state.imgurl = []

# if "alt_text" not in st.session_state:
st.session_state.alt_text = []

# ==========================================
# 3. 辅助函数定义
# ==========================================
def fetch_sheet_names():
    try:
        excel_file = database_path
        print(excel_file)
        xls = pd.ExcelFile(excel_file)
        # 获取所有sheet的名字，并存放在list中
        sheet_names = xls.sheet_names
        return sheet_names
    except FileNotFoundError as fnf_error:
        # 如果Excel文件未找到，显示错误信息
        st.session_state.vendor_name = []  # 更新 selectbox 的值
        st.session_state.product_list = []  # 更新 selectbox 的值
        return []

def fetch_keypoints(sheet_name):
    try:
        excel_file = database_path 
        df = pd.read_excel(excel_file, sheet_name=sheet_name)
        
        # 获取第一列的所有内容，存放在list中，并排除最后两个元素
        keypoints = df.iloc[:-2, 0].tolist()
        
        # 在控制台打印keypoints（可选）
        print(keypoints)
        
        return keypoints
    
    except FileNotFoundError as fnf_error:
        # 如果Excel文件未找到，显示错误信息
        # st.error(f"文件未找到: {fnf_error}")
        st.session_state.vendor_name = []  # 更新 selectbox 的值
        st.session_state.product_list = []  # 更新 selectbox 的值
        return []

    except ValueError as ve:
        # 如果读取Excel文件时出现ValueError，显示错误信息
        # st.error(f"读取 Excel 文件时出现错误: {ve}")
        st.session_state.vendor_name = []  # 更新 selectbox 的值
        st.session_state.product_list = []  # 更新 selectbox 的值
        return []
   
    
    except Exception as e:
        # 捕获其他可能的错误
        # st.error(f"出现未知错误: {e}")
        return []
        # st.session_state.vendor_name = "Cannot find keypoints"  # 更新 selectbox 的值
        # st.session_state.product_list = "Cannot find keypoints"  # 更新 selectbox 的值

def fetch_vendor_names(sheet_name):
    # 读取Excel文件中的Sheet
    excel_file = database_path
    df = pd.read_excel(excel_file, sheet_name=sheet_name)
    # 获取列名，存放在list中，
    vendor_names = df.columns.tolist()[1:]
    print(vendor_names)
    return vendor_names

def read_specific_cell_by_label(sheet_name, row_label, col_label):
    # 读取指定的表单
    df = pd.read_excel(database_path, sheet_name=sheet_name, index_col=0)
    
    # 使用 at 读取指定单元格内容
    cell_value = str(df.loc[row_label, col_label])
    
    product_list = cell_value.split(',')
    return product_list

def match(text, mark):
    # 使用正则表达式匹配 start 和 - 之间的内容
    if not isinstance(text, str):
        text = str(text)

    pattern = rf'{re.escape(mark)}(.*?)------'

    # 搜索匹配的内容
    matches = re.findall(pattern, text, re.DOTALL)

    if matches:
        # 获取匹配的内容
        contents = [match.strip() for match in matches]
        return "\n".join(contents)
    else:
        return("没有匹配到内容")

# def copy_to_clipboard():
#     app.clipboard_clear()  # 清空剪贴板
#     app.clipboard_append(scrolled_text.get("1.0", tk.END))  # 将 scrolledtext 中的内容复制到剪贴板
#     app.update()  # 更新应用程序，以确保剪贴板内容可用

def contains_markdown_images(text):
    if not text:
        return False

    # 确保 text 是字符串类型
    if isinstance(text, bytes):
        text = text.decode('utf-8')

    # 正则表达式模式
    pattern = r'!\[.*?\]\(.*?\)'
    return bool(re.search(pattern, text))

def extract_markdown_images(text):
    # 正则表达式模式
    pattern = r'!\[(.*?)\]\((.*?)\)'

    # 找到所有匹配的图片链接
    matches = re.findall(pattern, text)

    # 分别提取alt文本和URL
    alt_texts = [match[0] for match in matches]
    urls = [match[1] for match in matches]

    return alt_texts, urls

def load_action():
    st.session_state.database_path = database_path
    if not os.path.exists(database_path):
        st.toast('Error! Please check database file path', icon="🚨")
    else:
        st.toast("Load success", icon="✅")

def search_action():
    st.session_state.project_name = project_name
    sheet_list = fetch_sheet_names()
    keypoints = fetch_keypoints(project_name)
    if not sheet_list:
        st.toast('Error! Please check database file path', icon="🚨")
    else:
        if project_name in sheet_list:
            st.toast(f'Load {project_name} success', icon="✅")
        else:
            st.toast('Error! Input is empty or cannot find the project in the database', icon="🚨")

    st.session_state.keypoint.extend(keypoints)  # 更新 selectbox 的值
    

def keypoint_selected():
    
    vendor_names = fetch_vendor_names(project_name)
    st.session_state.vendor_name.extend(vendor_names)
    st.session_state.vendor_name_selection = None
    # st.session_state.product_list_selection = []

def vendor_name_selected():
    # 从 session_state 获取当前选中的 vendor_name
    sheet_name = project_name
    col_label = st.session_state.vendor_name_selection
    print(col_label)
    product_list = read_specific_cell_by_label(sheet_name, "产品列表", col_label)
    print(product_list)
    print(type(product_list[0]))
    if product_list[0] == "nan":
        print("无分类")
        st.session_state.product_list = ["View all"]
        st.session_state.product_list_selection = None
    else:
        st.session_state.product_list = product_list
        st.session_state.product_list_selection = None
        new_item = "View all"
        updated_choices =  st.session_state.product_list.insert(0, new_item)
    

def product_list_selected():
    filter_action()
    print("selectbox3 changed", st.session_state.product_list_selection)

def filter_action():
    row = st.session_state.keypoint_selection
    print(row)
    col = st.session_state.vendor_name_selection
    print(col)
    excel_file = database_path
    sheet_name = project_name
    df = pd.read_excel(excel_file, sheet_name=sheet_name, index_col=0)
    cell_value = df.loc[row, col]
    print(f"读取到{cell_value}")
    if pd.isna(cell_value):
        print("内容为空")
        st.session_state.txt = "There is no relevant record in the database"
    else:
        if contains_markdown_images(cell_value):
            alt_texts, urls = extract_markdown_images(cell_value)
            st.session_state.imgurl = urls
            st.session_state.alt_text = alt_texts
            st.session_state.txt = "Found image, scroll down to view image"
            
        else:
            filter = st.session_state.product_list_selection
            if filter == "View all":
                print(cell_value)
                st.session_state.txt = cell_value
                
            else:
                printed_value = match(cell_value, filter)
                print(printed_value)
                st.session_state.txt = printed_value

def response_generator():
    response = random.choice(
        [
            "Hello there! How can I assist you today?",
            "Hi, human! Is there anything I can help you with?",
            "Do you need help?",
        ]
    )
    for word in response.split():
        yield word + " "
        time.sleep(0.05)

# ==========================================
# 4. 页面布局与交互
# ==========================================
# Sidebar布局

# Set the title of the app
st.sidebar.title('Database Search')

# 创建一个容器，用于在sidebar中模拟列布局
with st.sidebar:

    # Input for database file path
    with st.container(border=False):
        left, right = st.columns([3, 1], vertical_alignment="bottom")
        with left:
            database_path = st.text_input('Database file path:', value=st.session_state.database_path)
        with right:
            st.button('Load', type="primary", use_container_width = True, on_click=load_action)
            # if st.button('Load', type="primary", use_container_width = True):
            #     st.session_state['database_path'] = database_path
            #     st.toast('File loading success', icon="ℹ️")
                
    # Project name selection
    with st.container(border=False):
        left2, right2 = st.columns([3, 1], vertical_alignment="bottom")
        with left2:
            project_name = st.text_input('Project name',placeholder="Enter project name here", )
                
        with right2:
            st.button("Search", type="primary", use_container_width = True, on_click=search_action)
    
    st.divider()

    # ChatBot Interface
    st.header("ChatBot")
    messages = st.container(height=60,border=False)
    messages.chat_message("assistant").write("Hi, what can I help you")
    if prompt := st.chat_input("Say something"):
        messages.chat_message("user").write(prompt)
        messages.chat_message("assistant").write(f"Echo: {prompt}")

# Main page content layout
col1, col2, col3 = st.columns(3)
with col1:
    keypoint = st.selectbox(
        "Keypoint",
        st.session_state.keypoint,
        key="keypoint_selection",
        on_change=keypoint_selected,
    )
with col2:
    vendor_name = st.selectbox(
        "Vendor name",
        st.session_state.vendor_name,
        key="vendor_name_selection",
        on_change=vendor_name_selected,
    )
with col3:
    product_list = st.selectbox(
        "Product list",
        st.session_state.product_list,
        key="product_list_selection",
        on_change=product_list_selected,
    )


txt = st.text_area(
    "Records",
    st.session_state.txt,
    height=320,
    placeholder="Records in the database"
)

with st.container():

    col4, col5, col6 = st.columns([0.6,0.1,0.1])
    with col4:
        st.write(f"[total {len(txt)} characters.]")
    with col5:
        if st.button("Refresh", use_container_width=True):
            filter_action()
    with col6:
        if st.button('Copy', use_container_width=True):
            pyperclip.copy(st.session_state.txt)
            st.toast("Copied to clipboard", icon="✅")


# Image display
image_placeholder = st.empty()
# 检查是否有图片URL，并且URL是一个列表
if st.session_state.imgurl:
    print(st.session_state.imgurl)
    image_placeholder.image(st.session_state.imgurl, caption=st.session_state.alt_text)
    st.toast(f'{", ".join(st.session_state.alt_text)} loaded successfully. Scroll down to view the image(s)', icon="✅")
   